import hello 

hello.print_result(23.0)