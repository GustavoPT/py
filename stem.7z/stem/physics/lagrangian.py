# lagrangian = l =
#  ke - pe = t - v 
#  equation of motion can 
#  be determined by  
#  d/dt (al/ax) = al / ax = 0
# where x and x represent 
# velocity and position in generalized 
# coordinates 
# where x and x represent 
# velocity and position in 
# generalized coordinates 
#  let v = x 
# and y = x 
#  l = ke - pe = 1/2 mx^2 - mgx 
# al / ax = 0 - mg 
# 
from vpython import *
box()