def force(mass,acceleration):
    return mass * acceleration 

