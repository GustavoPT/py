from vpython import *
box()

rot_axis = cylinder(pos=vector(0,0,-1),axis=vector(0,0,1),size=vector())

