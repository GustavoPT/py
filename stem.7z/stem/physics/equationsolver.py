import sys 
import os 

speed = 1.5 
power = 1.5 
acceleration = 1.6 
mass = 1.6 
gravity = 1.4 