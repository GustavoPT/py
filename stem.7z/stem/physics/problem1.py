# if you have four forces 
# coming from different directions 
# how do you calculate the total 
# net force 
# force normal 
# force from left 
# force upward 
# force downward 
