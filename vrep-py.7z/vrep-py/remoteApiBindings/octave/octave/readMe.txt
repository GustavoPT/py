Make sure you have following files in your directory, in order to run the various examples:

1. remApiSetup.m
2. the appropriate Octave remote API library: "remApi.oct"
3. simpleTest.m (or any other example program)