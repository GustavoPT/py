extern "C" {
#include "extApi.c"
}
