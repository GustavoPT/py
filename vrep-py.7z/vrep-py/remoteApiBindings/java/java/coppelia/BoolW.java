package coppelia;

public class BoolW
{
    boolean w;

    public BoolW(boolean b)
    {
        w = b;
    }

    public void setValue(boolean b)
    {
        w = b;
    }

    public boolean getValue()
    {
        return w;
    }
}